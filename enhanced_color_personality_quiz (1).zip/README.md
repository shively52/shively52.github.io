# Color Personality Quiz Website

## Overview
This is a fully functional color personality quiz website that helps users discover their color personality type (Blue, Red, Green, or Yellow) through a series of psychologically-relevant questions. The website includes Amazon affiliate links for product recommendations based on the user's personality type.

## Features
- 5 psychology-based questions to determine color personality
- Detailed personality profiles for each color type (Blue, Red, Green, Yellow)
- Custom color palette generation based on results
- Amazon affiliate links with your affiliate ID (colorquiz-20)
- Social sharing functionality
- Mobile-responsive design
- SEO optimized with relevant keywords
- No external dependencies - pure HTML, CSS, and JavaScript

## Installation
1. Simply upload the `index.html` file to your web hosting service
2. No database or server-side processing required

## Customization Options
- **Affiliate ID**: The Amazon affiliate ID is set to "colorquiz-20". You can change this by searching for this text in the HTML file and replacing it with your own affiliate ID.
- **Ad Sense**: The Google AdSense placeholder is in the HTML. Replace "ca-pub-XXXXXXXXXX" with your actual AdSense publisher ID when approved.
- **Products**: You can update the product links in the `colorProfiles` object in the JavaScript section to feature different Amazon products.
- **Colors/Styling**: Modify the CSS variables in the `:root` selector to change the color scheme.

## How It Works
1. Users answer 5 personality-based questions
2. Each answer is associated with a specific color (Blue, Red, Green, or Yellow)
3. The script calculates the dominant color based on the user's answers
4. The results page displays:
   - The user's color personality type
   - A harmonious color palette based on their result
   - A description of their personality traits
   - Personalized Amazon product recommendations
   - Social sharing options

## SEO Information
The website is optimized for search engines with:
- Relevant meta title and description
- Comprehensive keyword list in meta tags
- Semantic HTML structure
- Mobile-friendly responsive design

## Testing
The website has been thoroughly tested and all functionality works as expected:
- Quiz navigation
- Color calculation
- Results display
- Amazon affiliate links
- Social sharing buttons

## Next Steps
1. Deploy the website to your hosting service
2. Monitor Amazon affiliate performance
3. Once Google AdSense is approved, update the AdSense code
4. Consider adding Google Analytics for visitor tracking

Enjoy your new color personality quiz website!
